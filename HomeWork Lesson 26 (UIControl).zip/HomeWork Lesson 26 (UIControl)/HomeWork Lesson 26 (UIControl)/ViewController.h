//
//  ViewController.h
//  HomeWork Lesson 26 (UIControl)
//
//  Created by Anton Gorlov on 24.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *pictureImageView;

@property (weak, nonatomic) IBOutlet UISegmentedControl *picturesSchemeControl;
@property (weak, nonatomic) IBOutlet UISlider *speedControlSlider;


- (IBAction)actionScaleSwitch:(UISwitch *)sender;
- (IBAction)actionTranslationSwitch:(UISwitch *)sender;
- (IBAction)actionRotationSwitch:(UISwitch *)sender;

- (IBAction)actionSchemeControl:(UISegmentedControl *)sender;




@end


//
//  ViewController.m
//  HomeWork Lesson 26 (UIControl)
//
//  Created by Anton Gorlov on 24.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (assign, nonatomic) CGFloat scale;
@end


@implementation ViewController


/*
 Ученик.
 
 1. Расположите тестируюмую вьюху (imageView) на верхней половине экрана
 2. На нижней половине создайте 3 свича: Rotation, Scale, Translation. По умолчанию все 3 выключены
 3. Также создайте сладер скорость, со значениями от 0.5 до 2, стартовое значение 1
 4. Создайте соответствующие проперти для свитчей и слайдера, а также методы для события valueChanged
*/

/*
 Студент.
 
 5. Добавьте сегментед контрол с тремя разными сегментами
 6. Они должны соответствовать трем разным картинкам, которые вы должны добавить по 1-й картинке на каждый сегмент
 7. Когда переключаю сегменты, то картинка должна меняться на соответствующую
*/

/*
 Мастер.
 
 8. Как только мы включаем один из свичей, наша вьюха должна начать соответствующую анимацию
 (либо поворот, либо скеил, либо перенос). Используйте свойство transform из урока об анимациях
 9. Так же следует помнить, что если вы переключили свич, но какойто другой включен одновременно с ним, то вы должны делать уже двойную анимацию. Например и увеличение и поворот одновременно (из урока про анимации)
 10. Анимации должны быть бесконечно повторяющимися, единственное что их может остановить, так это когда все три свича выключены
*/

/*
 Супермен.
 
 11. Добавляем использование слайдера. Слайдер регулирует скорость. То есть когда значение на 0.5, то скорость анимаций должна быть в два раза медленнее, а если на 2, то в два раза быстрее обычной.
 12. Попробуйте сделать так, чтобы когда двигался слайдер, то анимация обновлялась без прерывания, а скорость изменялась в соответствующую сторону.
 
 Такое вот задание :)
*/
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark- Methods




#pragma mark- Actions

- (IBAction)actionScaleSwitch:(UISwitch *)sender { //масштаб
    
    if (sender.isOn) {
        
        if (self.scale == 1.4f) self.scale = 0.5f;
        else self.scale = 1.4f;
        
        [UIView animateWithDuration:3.f - self.speedControlSlider.value //меняем скорость с помощью "Slider"
                              delay:0
                              options:UIViewAnimationOptionCurveEaseInOut
                                     |UIViewAnimationOptionBeginFromCurrentState
         
                         animations:^{
                             self.pictureImageView.transform = CGAffineTransformScale(self.pictureImageView.transform, self.scale, self.scale); //метод,который скейлит матрицу,которую засунем.
                         }
                         completion:^(BOOL finished) {
                             [self actionScaleSwitch:sender];//безконечное повторение анимации
                         }];

    }
    
}

- (IBAction)actionTranslationSwitch:(UISwitch *)sender { //перемещение
    if (sender.isOn) {
        
        CGPoint newCenter = CGPointMake(arc4random_uniform(150)+270, arc4random_uniform(150)+270);

        
        [UIView animateWithDuration:2.f - self.speedControlSlider.value
                              delay:0
                            options:UIViewAnimationOptionCurveEaseInOut
                                   |UIViewAnimationOptionBeginFromCurrentState
         
                         animations:^{
                             self.pictureImageView.center = newCenter;
                             //center - точка,относительно середины frame
                         }
                         completion:^(BOOL finished) {
                             [self actionTranslationSwitch:sender];
                             
                         }];

    }
    
   
  
    
}

- (IBAction)actionRotationSwitch:(UISwitch *)sender { //поворот
    
    if (sender.isOn) {
        [UIView animateWithDuration:2.3f - self.speedControlSlider.value
                              delay:0
                            options:UIViewAnimationOptionCurveEaseInOut
                                   |UIViewAnimationOptionBeginFromCurrentState
        
                         animations:^{
                             self.pictureImageView.transform = CGAffineTransformRotate(self.pictureImageView.transform, M_PI_2);                         }
                         completion:^(BOOL finished) {
                             [self actionRotationSwitch:sender];
                         }];
    }
   
    
    
}

- (IBAction)actionSchemeControl:(UISegmentedControl *)sender {
    
    switch (sender.selectedSegmentIndex) { //по умолчанию стартует с 1й фотки
        case 0:
            self.pictureImageView.image = [UIImage imageNamed:@"1.jpg"];
            break;
            
        case 1:
            self.pictureImageView.image = [UIImage imageNamed:@"2.jpg"];
            break;
            
        case 2:
            self.pictureImageView.image = [UIImage imageNamed:@"3.jpg"];
            break;
            
        default:
            break;
    }
    
}

- (IBAction)actionSpeedSlider:(UISlider *)sender {
}


@end

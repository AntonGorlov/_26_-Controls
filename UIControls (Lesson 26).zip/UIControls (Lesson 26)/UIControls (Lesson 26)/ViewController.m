//
//  ViewController.m
//  UIControls (Lesson 26)
//
//  Created by Anton Gorlov on 24.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

typedef enum {
    AGColorShemeTypeRGB,
    AGColorShemeTypeHSV
    
}AGColorShemeType;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self refreshScreen]; // не забываем ставить сюда ссылку!!!!!!!!!!!!!!
    self.colorShemeControl.selectedSegmentIndex = AGColorShemeTypeRGB; //по умолчанию стартуем с RGB
    
    
    
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark- Actions

- (IBAction)actionSlider:(UISlider *)sender {
   // NSLog(@"%0.2f", sender.value);
    self.infoLabel.text = [NSString stringWithFormat:@"%1.2f",sender.value];
    [self refreshScreen];
}

#pragma mark- Private Methods

- (void) refreshScreen {

    CGFloat red = self.redComponentSlider.value;
    CGFloat green = self.greenComponentSlider.value;
    CGFloat blue = self.blueComponentSlider.value;
    
    self.infoLabel.text = [NSString stringWithFormat:@"%1.2f, %1.2f, %1.2f", red,green,blue];
    // UIColor* color = [UIColor colorWithRed:red green:green blue:blue alpha:1.f];
    // self.view.backgroundColor = color; // весь экран меняет цвет

    
    UIColor* color = nil;

    if (self.colorShemeControl.selectedSegmentIndex == AGColorShemeTypeRGB) {
        color = [UIColor colorWithRed:red green:green blue:blue alpha:1.f];
    }else {
        color = [UIColor colorWithHue:red saturation:green brightness:blue alpha:1.f];
    }
    
    self.view.backgroundColor = color; //весь экран меняет цвет
    
    //методы , которые возвращают несколько параметров
    
    CGFloat hue, saturation, brightness, alpha; // ОБЬЯВЛЯЕМ оттенок,насыщеность,яркость
    
    NSString* result = @""; //соз строку
    
    if ([color getRed:&red green:&green blue:&blue alpha:&alpha]) { //метод,кот возвращает параметры.Принимает не "Float", а указатели на "Float" (BOOL - удалось получить эти компоненты или нет). "&" - чтобы взять указатели на наши данные (АМПЕРСАНДА).
        result = [result stringByAppendingFormat:@"RGB: %1.2f, %1.2f, %1.2f ", red, green, blue];//строка с добавлением формата
    }else {
        
        result = [result stringByAppendingFormat:@"RGB: NO DATA"]; //если не получилось взять
    
    }
    
    if ([color getHue:&hue saturation:&saturation brightness:&brightness alpha:&alpha]) {
        
        result = [result stringByAppendingFormat:@"HSV: %1.2f, %1.2f, %1.2f ",hue, saturation, brightness];
        
    }else {
     
        result = [result stringByAppendingFormat:@"HSV: NO DATE"];
    }
    
    self.infoLabel.text = result;
    self.view.backgroundColor = color;
    
    
}

- (IBAction)actionEnable:(UISwitch *)sender { //нажмем на UISwitch и там есть методы
    
    self.redComponentSlider.enabled = self.greenComponentSlider.enabled = self.blueComponentSlider.enabled = sender.isOn;
  /*
    [[UIApplication sharedApplication] beginIgnoringInteractionEvents]; // c этого момента игнорируем Event
    double delayInSeconds = 2.f; //через сколько сек начнет работать кнопка Enable
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(delayInSeconds * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([[UIApplication sharedApplication] isIgnoringInteractionEvents]) {// начинаем игнорить
            [[UIApplication sharedApplication] endIgnoringInteractionEvents]; // заканчиваем игнорить
        }
    });
 */
}

@end

//
//  UIControls__Lesson_26_Tests.m
//  UIControls (Lesson 26)Tests
//
//  Created by Anton Gorlov on 24.02.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface UIControls__Lesson_26_Tests : XCTestCase

@end

@implementation UIControls__Lesson_26_Tests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
